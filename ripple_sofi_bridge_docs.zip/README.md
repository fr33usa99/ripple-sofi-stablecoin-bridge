# ripple-sofi-stablecoin-bridge

🔁 MVP CLI demo of a Ripple–SoFi stablecoin bridge using:
**USDC → XRP → EURC**

Authored by Adam Sanchez under GENIUS Act–compliant architecture.

---

## 🧠 Purpose

Demonstrates how a U.S.-licensed FinTech like SoFi could:
- Hold regulated USDC balances
- Use XRP to bridge foreign corridors 24/7
- Settle into region-specific stablecoins like EURC
- Log all steps for legal compliance

---

## 🧩 Modules Included

| File | Function |
|------|----------|
| `usdc_mock.py` | Simulates SoFi wallet with USDC |
| `xrp_bridge.py` | Converts XRP and sends it to foreign destination |
| `dex_swap_mock.py` | Swaps XRP → EURC at mock exchange rate |
| `compliance_logger.py` | Logs tx ID, amounts, and routing path |
| `run_demo.py` | Full CLI runner for bridge scenario |

---

## 📄 Business Pitch

See attached:  
📎 `Ripple_SoFi_Bridge_Pitch_Adam_Sanchez.pdf`

---

## 📊 Estimated Revenue Impact

| Metric | Estimate |
|--------|----------|
| FX Users (monthly) | 100,000 |
| Avg Transfer | $500 |
| Spread/Fee Revenue | $5–7 per tx |
| SoFi Profit | $350K+/mo |
| Ripple Profit | $150K+/mo |

---

## 👤 Author

**Adam Sanchez**  
Founder, Pacific Sodium Technologies  
📧 fr33usa@gmail.com  
🔗 [github.com/fr33usa99](https://github.com/fr33usa99)

---

## ⚖️ License

MIT License (see [LICENSE](./LICENSE))